#!/usr/bin/env python3
import sys,time
sys.path.insert(0,'/mnt/data/erdos2275')
from state2275_hn_milp import solve_any, CONST, HRHS
MS=[0x0f,0x17,0x1f,0x33,0x37,0x3f,0x55,0x57,0x5f,0x77,0x7f,0xff]
print('STATE 2275 DEPTH-ONE SURPLUS + HN-BAD EXHAUSTIVE CHECK')
print('fixed partial: 11** 1*1* *22* 123* 1**1 *3*2 13*3')
print('HN threshold HRHS=',HRHS,'CONST=',CONST)
print('surplus downsets=',[hex(x) for x in MS])
all_inf=True
st=time.time()
for M in MS:
    print('\nCASE',hex(M),flush=True)
    r,meta=solve_any(M,tlim=120)
    inf=(r.x is None and 'infeasible' in r.message.lower())
    print('CERTIFIED_INFEASIBLE=',inf,flush=True)
    all_inf &= inf
print('\nOVERALL_ALL_12_INFEASIBLE=',all_inf)
print('elapsed=',time.time()-st)
if not all_inf: raise SystemExit(1)
