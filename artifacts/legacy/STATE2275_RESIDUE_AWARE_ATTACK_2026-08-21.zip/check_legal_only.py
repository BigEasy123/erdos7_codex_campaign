import sys
sys.path.insert(0,'/mnt/data/erdos2275')
from state2275_hn_milp import *
from scipy.optimize import milp,LinearConstraint,Bounds
from scipy.sparse import lil_matrix
import numpy as np

def legal(M):
    names=[];lb=[];ub=[];ii=[]
    def add(n): j=len(names); names.append(n);lb.append(0);ub.append(1);ii.append(1);return j
    qidx={(m,v):add(('q',m,v)) for m in FUT for v in Q[m]}
    Ts=[T for T in range(8) if M>>T&1]
    xidx={(T,v,z):add(('x',T,v,z)) for T in Ts for v,z in X[T]}
    eidx={a:add(('e',a)) for a in R}
    rows=[];los=[];his=[]
    def row(d,lo=-np.inf,hi=np.inf):rows.append(d);los.append(lo);his.append(hi)
    for m in FUT:row({j:1 for (mm,v),j in qidx.items() if mm==m},1,1)
    for i,m in enumerate(FUT):
      Im=bits(m)
      for n in FUT[i+1:]:
       if not subset(m,n):continue
       In=bits(n)
       for mv in Q[m]:
        jm=qidx[m,mv]; js=[qidx[n,nv] for nv in Q[n] if restrict(nv,In,Im)==mv]
        if js: row({jm:1,**{j:1 for j in js}},hi=1)
    for T in Ts:row({j:1 for (TT,v,z),j in xidx.items() if TT==T},1,1)
    for T in Ts:
      ST=osupp(T)
      for U in Ts:
       if T>=U or not subset(T,U):continue
       SU=osupp(U)
       for tv,tz in X[T]:
        jt=xidx[T,tv,tz];js=[xidx[U,uv,uz] for uv,uz in X[U] if uz==tz and restrict(uv,SU,ST)==tv]
        if js:row({jt:1,**{j:1 for j in js}},hi=1)
    for T in Ts:
      S=osupp(T);Sm=sum(1<<i for i in S)
      for m in FUT:
       if not subset(m,Sm):continue
       I=bits(m)
       for qv in Q[m]:
        jq=qidx[m,qv];js=[xidx[T,xv,z] for xv,z in X[T] if restrict(xv,S,I)==qv]
        if js:row({jq:1,**{j:1 for j in js}},hi=1)
    row({j:1 for j in eidx.values()},lo=1)
    for a,je in eidx.items():
      for m in FUT:
        I=bits(m);av=tuple(a[i] for i in I);jq=qidx.get((m,av))
        if jq is not None:row({je:1,jq:1},hi=1)
      for z in range(3):
        d={je:1}
        for T in Ts:
          S=osupp(T);av=tuple(a[i] for i in S);jx=xidx.get((T,av,z))
          if jx is not None:d[jx]=d.get(jx,0)-1
        row(d,hi=0)
    A=lil_matrix((len(rows),len(names)))
    for r,d in enumerate(rows):
      for j,v in d.items(): A[r,j]=v
    res=milp(np.zeros(len(names)),integrality=np.ones(len(names)),bounds=Bounds(np.array(lb),np.array(ub)),constraints=LinearConstraint(A.tocsr(),np.array(los),np.array(his)),options={'time_limit':30,'mip_rel_gap':0})
    print(hex(M),res.message,'inc',res.x is not None)
    if res.x is not None:
      ex=[a for a,j in eidx.items() if res.x[j]>.5]; qs=[(m,v) for (m,v),j in qidx.items() if res.x[j]>.5]; xs=[(T,v,z) for (T,v,z),j in xidx.items() if res.x[j]>.5]
      print('ex',ex[:3],'q',qs,'x',xs)
    return res

for M in [0xf,0x1f,0x3f,0xff]: legal(M)
