# Erdős #7 — State 2275 residue-aware surplus/HN checkpoint

Date: 2026-08-21
Status: **new finite depth-one closure; not a QED**

## 1. Focal state

Canonical BBMST partial state 2275 is

```
11**  1*1*  *22*  123*  1**1  *3*2  13*3
```

on the reduced shallow box `2 x 4 x 6 x 10`, leaving 331 shallow atoms before the four remaining squarefree supports `12,13,14,15` are chosen.

This is the isolated partial whose adjusted BBMST value spikes above the handoff threshold in the Stage-24 recomputation.

## 2. Combined finite model

`state2275_hn_milp.py` simultaneously encodes:

1. the seven fixed state-2275 squarefree residue classes;
2. exactly one legal residue class on each remaining squarefree support `12,13,14,15`;
3. comparable-modulus residue incompatibility among the squarefree completions;
4. a divisor-closed depth-one terminal support downset `M` among the eight squarefree cofactors of `5*7*11`;
5. exactly one residue for each terminal modulus `3^2 d` represented by `M`;
6. comparable deep/deep residue incompatibility;
7. deep-versus-squarefree divisor incompatibility (the depth-one form of the forced blocker/nonnesting geometry);
8. a freely chosen first exhausted shallow parent `a` via binary variables `e_a`;
9. coverage of all three second-3-adic children of every selected exhausted parent;
10. the Hough--Nielsen joint `(B2,B3)` bad-gate dual at the exact saved threshold
   `HRHS = 0.48249312963046986`, with
   `alpha = 0.011800206435906386`,
   `beta = 0.0010516899397334059`.

The exhausted parent is *not* fixed in advance.  The MILP may choose any of the 331 shallow residual atoms that survives the four squarefree completion classes.

## 3. Exhaustive surplus support-downset classification

There are 19 divisor-closed support downsets in the Boolean lattice on the three cofactor primes.  The 12 surplus cases (cardinality at least four) are

```
0x0f, 0x17, 0x1f, 0x33, 0x37, 0x3f,
0x55, 0x57, 0x5f, 0x77, 0x7f, 0xff.
```

At the saved HN bad threshold, **all 12 MILPs are infeasible**.

Therefore, within this depth-one squarefree-cofactor model:

> No legal state-2275 surplus first-exhaustion packet can simultaneously remain Hough--Nielsen-bad after legal completion of the four remaining squarefree supports.

Equivalently, every legal state-2275 depth-one surplus first exhaustion is forced into the HN-good side of the BBMST-or-HN dichotomy.

## 4. Sanity check against accidental overconstraint

Removing the HN-bad dual leaves legal first-exhaustion systems feasible.  Explicit legal witnesses were found for representative support patterns `0x0f`, `0x1f`, `0x3f`, and `0xff`.

For these explicit legal packets, a separate primal LP minimizing the actual joint HN functional gave approximately

```
M=0x0f : 0.3541960189
M=0x1f : 0.3519457544
M=0x3f : 0.3579111521
M=0xff : 0.3574201319
```

all well below `0.4824931296`.

Thus the infeasibility is specifically the conflict between *legal first exhaustion* and *HN-badness*, not an artifact that forbids all packets.

## 5. What this closes and what it does not

### Closed by this checkpoint

The hardest isolated squarefree partial, state 2275, is closed for **depth-one terminal classes with squarefree cofactors supported on `5,7,11`**, across every surplus divisor-downset and every possible exhausted parent, using the residue-aware HN gate.

### Still required before QED

This finite result does **not** by itself prove that arbitrary deeper 3-adic packets or repeated cofactor powers reduce to the depth-one squarefree model.  The next theorem must lift this closure through arbitrary depth while preserving the least-counterexample residue structure.

The natural next attack is a finite-state/first-exhaustion induction:

- exact-three packets: already certified;
- depth-one surplus state 2275: closed here;
- deeper/repeated-power packet: use downset descent, second-prime pivot, or an automaton/Bellman potential to show it either reduces to a certified shallower state, forces new-prime support, or enters the HN-good gate.

## 6. Rigor status

The combinatorial model is explicit and finite, but the infeasibility calls currently rely on SciPy/HiGHS floating-point MIP solving.  A publication-grade finish should extract an independently checkable certificate (exact branch-and-cut/SAT proof log, rational Farkas certificates at leaves, or kernel-checked verification) after the arbitrary-depth reduction is finalized.

No QED is claimed at this checkpoint.

## 7. First depth-two probe

To test whether the closure automatically propagates one further 3-adic digit, a depth-two model was built with nested support downsets `M2 subset M1`, explicit residues at both depths, all cross-depth comparability constraints, future squarefree completion, a freely chosen first-exhausted depth-one parent, and the HN bad dual through exponent level 3.

For the minimal surplus pair `M1=M2=0x0f` the monolithic model has approximately

```
10,226 variables
2,385 binary variables
14,983 constraints
```

and did not resolve within the direct solver window.  Its continuous LP relaxation is feasible; the exhausted-parent mass is fractional (`sum e = 1`, largest `e ≈ 0.3586735`).  Thus depth two is **not** closed by a trivial relaxation argument, and the next exact computation should use orbit fixing / lazy triangle cuts / Bellman-state decomposition rather than a monolithic MILP.

This depth-two diagnostic does not weaken the exact depth-one closure above; it identifies the next finite scaling bottleneck.
