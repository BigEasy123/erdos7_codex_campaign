# Erdős Problem #7 — Hunter-overlap dispersion checkpoint

Date: 2026-08-22

Status: **new finite arbitrary-depth reduction at state 2275; no QED claimed.**

## 1. Retained exact arbitrary-depth input

The corrected low-four tower verifier checks all 7,637 canonical low-four partial states.  Every arbitrary continuation supported only on `{3,5,7,11}` leaves positive mass in the monotone canonical-tail model.  The unique worst state is 2275,

`11** 1*1* *22* 123* 1**1 *3*2 13*3`,

with `|R|=331`, tower capacity `145247/480`, and residual fraction

`13633/158880 = 0.08580689828801612 > 0`.

The stronger support-wise fractional allocation relaxation also implies that every actual continuation leaves descendants over at least 42 distinct shallow parents.

## 2. Exact-heavy + fractional-tail hierarchy

For every radical support `I`, enumerate every exponent vector whose relative cylinder density is at least a cutoff `theta`; each such modulus is forced to choose one actual shallow residue cylinder.  The remaining infinite geometric tail below `theta` is kept as a fractional support-wise budget.  This is a relaxation of every arbitrary-depth continuation, and becomes sharper as `theta` decreases.

At state 2275, after enforcing:

- legal future squarefree base classes on supports 12,13,14,15;
- future-base / comparable-tail shallow incompatibility;
- exponent-lattice divisor completion among all represented heavy vectors;
- the exact BBMST-bad LP dual;

the BBMST-only relaxation remains feasible:

- `theta=0.02`: 11,050 variables, 9,168 binaries, 14,447 rows; a bad relaxation selects 114 exhausted parents and leaves 217;
- `theta=0.01`: 14,443 variables, 12,561 binaries, 20,131 rows; a bad relaxation selects 88 exhausted parents and leaves 243.

Thus divisor completion and shallow comparability alone do not prove the BBMST handoff.

## 3. Deeper-digit compatibility does not kill the heavy core

For the `theta=0.02` witness, only 34 exact heavy moduli are selected (41 classes including the seven fixed squarefree mixed bases).  Restoring actual deeper p-adic residue digits gives a finite compatibility CSP with:

- 337 residue-choice variables/options,
- 142 comparable class pairs,
- 210 conflicting option pairs.

The CSP is feasible.  Hence the witness is not ruled out merely by pairwise comparable-modulus residue incompatibility.

## 4. New Hunter/CRT exhaustion lemma

Fix one shallow parent `a`.  After conditioning on its first digits, an exact heavy class becomes one residue class modulo a residual modulus `m_i = 3^u 5^v 7^w 11^z`.

For any two selected residual moduli with `gcd(m_i,m_j)=1`, CRT forces their residue classes to intersect in relative density exactly `1/(m_i m_j)`, regardless of deeper residue choices.

Therefore, for any forest `T` on the selected heavy classes whose edges join coprime residual moduli,

`union_density <= sum_i 1/m_i - sum_{ij in T} 1/(m_i m_j)`.

Choosing a maximum-weight such forest gives a residue-independent Hunter upper bound.  Adding the unresolved fractional tail by the union bound remains valid.

This is a necessary condition for a shallow parent to be genuinely exhausted.  It is strictly stronger than the old scalar condition `sum densities >= 1`.

## 5. Audit of the strongest theta=0.02 BBMST-bad witness

The smeared model claims 114 exhausted parents.

Applying the Hunter/CRT bound plus the full unresolved fractional-tail allocation gives:

- only 26 of those 114 claimed parents can even reach capacity 1;
- over all 331 shallow parents, only 32 can possibly reach capacity 1.

Now pessimistically delete **all 32** potentially exhaustible parents.  Re-optimizing the BBMST probability measure on the remaining 299 parents gives

`F_min = 8.902830270619036 < 9.019`,

with positive margin

`0.11616972938096382`.

Hence this entire BBMST-bad witness is rigorously spurious, independently of the assignment of deeper p-adic digits.

## 6. Hunter cuts as a branch-and-cut certificate

For a witness-selected maximum forest, the Hunter condition can be written as a globally valid linear cut.

If `x_i` is the selected indicator for heavy class `i`, `e_a` the exhausted-parent indicator, `t_a` the unresolved tail union-bound contribution, and `E(T)` a forest of coprime residual-modulus pairs, then

`e_a <= sum_i w_i x_i + t_a - sum_{ij in E(T)} w_ij (x_i + x_j - 1)`

is valid, where `w_i=1/m_i`, `w_ij=1/(m_i m_j)`.

For the current witness all forest endpoints are selected, so this cut reproduces the exact Hunter correction.  For other selections, `x_i+x_j-1 <= 1_{i,j both selected}`, so the right side only becomes larger; therefore the cut remains a valid relaxation globally.

### First Benders iterations

At `theta=0.02`:

- initial bad witness: 114 claimed exhausted;
- 26 Hunter-potential, 88 invalid;
- **88 valid Hunter cuts** generated in the first separation pass.

The second integer solve exceeded the execution window and is recorded as **unknown**, not infeasible.

At `theta=0.05`, three completed iterations gave:

| iteration | claimed exhausted | Hunter-potential | new Hunter cuts |
|---:|---:|---:|---:|
| 0 | 107 | 68 | 39 |
| 1 | 101 | 40 | 61 |
| 2 | 92 | 40 | 52 |

Thus 152 overlap cuts were generated before the tool window ended.  No infeasibility claim is made from the timeout.

After the first 88 `theta=0.02` cuts, the **continuous** relaxation remains feasible, but its total fractional exhaustion is only about `10.8196709333`, with maximum individual exhaustion variable about `0.9798743`.  Therefore the final obstruction is genuinely integer/combinatorial, not a missing scalar inequality.

## 7. Failed shortcut checked in this pass

A direct pure-tower-transversal optimization was also tested.  Minimizing the sufficient scalar final-BBMST expression

`F_start + (9.019-0.25) * epsilon_mixed`

over shallow probability measures gives approximately

`11.8998535 > 9.019`.

So the Stage-15 scalar mixed-deletion shortcut does not close state 2275; residue-aware Hunter cuts are essential.

## 8. Current single computational target

The best next finite target is now:

> **State-2275 Hunter branch-and-cut theorem.** At a fixed exact-heavy cutoff (currently `theta=0.02`), prove the BBMST-bad heavy+fractional-tail master infeasible after exhaustive Hunter/CRT forest separation and the existing divisor-completion/comparability constraints.

Because the sub-cutoff tail is retained as a full fractional geometric budget, infeasibility at a fixed cutoff is already an arbitrary-depth statement; it does **not** require taking `theta -> 0`.

If a Hunter-feasible BBMST-bad integer witness survives, it is a much smaller exact packet and should then be tested against the chain/fork, surplus-triangle, blocker, and HN high-residue machinery.

## 9. Proof architecture

The shortest current proof route is:

1. least hypothetical odd DCS / irredundancy / divisor completion;
2. consecutive odd-prime support;
3. exact `L0` exclusion;
4. canonical low-four shallow partial;
5. exact arbitrary-depth `{3,5,7,11}` tower noncoverage over all 7,637 states;
6. state-2275 Hunter-overlap dispersion certificate (current finite target);
7. lift via state-2275 extremality / Stage-24 filters to the remaining canonical states;
8. BBMST or HN low-prefix handoff;
9. finite 13--73 sieve and published >73 termination;
10. contradiction.

## 10. Evidence-level warning

- The 7,637-state low-four tower theorem is exact-rational finite + geometric.
- The Hunter forest inequality is an exact mathematical inequality.
- The witness audit `F_min=8.902830270619036` currently uses floating LP optimization and should be rationalized once the branch-and-cut closes.
- Solver timeouts are never treated as infeasibility.
- No QED is claimed at this checkpoint.
