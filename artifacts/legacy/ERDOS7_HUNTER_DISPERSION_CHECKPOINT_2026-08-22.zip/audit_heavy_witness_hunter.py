#!/usr/bin/env python3
import json,ast,math,sys
from fractions import Fraction as F
sys.path.insert(0,'/mnt/data/erdos2275');import state2275_hn_milp as s
P=(3,5,7,11);R=s.R
W=json.load(open('/mnt/data/erdos2275/TOWER_HEAVY_BBMST_V3_002_WITNESS.json'))
# selected heavy: residual modulus after conditioning first shallow digit
H=[]
for z in W['heavy_selected']:
 nm=ast.literal_eval(z['name']);_,m,h,es,v=nm;I=s.bits(m)
 q=1
 for i,e in zip(I,es):q*=P[i]**(e-1)
 H.append((m,tuple(v),q,tuple(es)))
T={(t['m'],tuple(t['v'])):F(str(t['load'])) for t in W['tail']}

def hunter(mods):
 if any(q==1 for q in mods):return F(1)
 base=sum((F(1,q) for q in mods),F(0))
 # max spanning forest on coprime graph, weights 1/(mn)
 edges=[]
 for i in range(len(mods)):
  for j in range(i+1,len(mods)):
   if math.gcd(mods[i],mods[j])==1:edges.append((F(1,mods[i]*mods[j]),i,j))
 edges.sort(reverse=True)
 par=list(range(len(mods)))
 def find(x):
  while par[x]!=x:par[x]=par[par[x]];x=par[x]
  return x
 corr=F(0)
 for w,i,j in edges:
  a,b=find(i),find(j)
  if a!=b:par[a]=b;corr+=w
 return min(F(1),base-corr)
vals=[]
for j,a in enumerate(R):
 mods=[]
 for m,v,q,es in H:
  I=s.bits(m)
  if tuple(a[i] for i in I)==v:mods.append(q)
 tail=F(0)
 for m in range(1,16):tail+=T.get((m,tuple(a[i] for i in s.bits(m))),F(0))
 hu=hunter(mods);cap=min(F(1),hu+tail)
 vals.append((float(cap),float(hu),float(tail),j,mods))
ex=set(W['exhausted']);ev=[x for x in vals if x[3] in ex]
print('claimed exhausted',len(ev))
print('Hunter+tail can reach 1:',sum(x[0]>=1-1e-12 for x in ev))
print('all R potentially exhaustible',sum(x[0]>=1-1e-12 for x in vals))
print('max below-one cap',max(x[0] for x in ev if x[0]<1))
print('top nontrivial:')
for x in sorted([x for x in ev if x[0]<1],reverse=True)[:20]:print(x[:4],x[4])
