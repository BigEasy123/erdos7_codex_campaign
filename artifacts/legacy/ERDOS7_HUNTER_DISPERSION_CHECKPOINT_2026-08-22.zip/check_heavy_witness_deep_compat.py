#!/usr/bin/env python3
import json,ast,sys,time
from itertools import product
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import lil_matrix
sys.path.insert(0,'/mnt/data/erdos2275');import state2275_hn_milp as s
P=(3,5,7,11)
W=json.load(open('/mnt/data/erdos2275/TOWER_HEAVY_BBMST_V3_002_WITNESS.json'))
classes=[]
# canonical fixed mixed squarefree bases
for m,v in s.FIX.items():
 e=tuple(1 if m>>i&1 else 0 for i in range(4)); shallow={i:v[k] for k,i in enumerate(s.bits(m))}
 classes.append(('fix'+str(m),e,shallow))
# selected heavy classes (includes future bases)
for z in W['heavy_selected']:
 nm=ast.literal_eval(z['name']);_,m,h,es,v=nm;I=s.bits(m)
 e=[0]*4;sh={}
 for k,i in enumerate(I):e[i]=es[k];sh[i]=v[k]
 classes.append((f'h{m}_{h}',tuple(e),sh))
# dedupe exact same modulus exponent vector? there is one modulus each; fixed base not duplicated by heavy except FUT not fixed.
# residue options: represent residue digits in base p as tuple digits length e_i, first digit = shallow reduced label.
opts=[]
for name,e,sh in classes:
 arr=[]
 coords=[i for i,x in enumerate(e) if x]
 ranges=[]
 for i in coords:
  # deeper digit tuples only; first digit fixed
  ranges.append(list(product(range(P[i]),repeat=e[i]-1)))
 for tails in product(*ranges):
  rr={}
  for i,t in zip(coords,tails):rr[i]=(sh[i],)+tuple(t)
  arr.append(rr)
 opts.append(arr)
print('classes',len(classes),'options total',sum(map(len,opts)),'max',max(map(len,opts)),flush=True)
# Pair is modulus-comparable iff exponent vectors coordinatewise ordered.
def leq(e,f):return all(a<=b for a,b in zip(e,f))
def compatible(ri,rj,emin):
 # compare digits through smaller exponent on every supported coord
 for k,n in enumerate(emin):
  if n and ri[k][:n]!=rj[k][:n]:return False
 return True
# assignment vars one per option
starts=[];n=0
for arr in opts:starts.append(n);n+=len(arr)
rows=[];los=[];his=[]
def row(d,lo=-np.inf,hi=np.inf):rows.append(d);los.append(lo);his.append(hi)
for i,arr in enumerate(opts):row({starts[i]+k:1 for k in range(len(arr))},1,1)
conf=0;compairs=0
for i in range(len(classes)):
 ei=classes[i][1]
 for j in range(i+1,len(classes)):
  ej=classes[j][1]
  if leq(ei,ej):small=i;large=j;emin=ei
  elif leq(ej,ei):small=j;large=i;emin=ej
  else:continue
  compairs+=1
  # if shallow already incompatible there will be no option conflicts
  for a,ra in enumerate(opts[i]):
   js=[]
   for b,rb in enumerate(opts[j]):
    if compatible(ra,rb,emin):js.append(starts[j]+b)
   if js:
    d={starts[i]+a:1};d.update({q:1 for q in js});row(d,hi=1);conf+=len(js)
A=lil_matrix((len(rows),n))
for r,d in enumerate(rows):
 for j,v in d.items():A[r,j]=v
print('comparable pairs',compairs,'conflicting option pairs',conf,'vars',n,'rows',len(rows),flush=True)
st=time.time();z=milp(np.zeros(n),integrality=np.ones(n,dtype=int),bounds=Bounds(np.zeros(n),np.ones(n)),constraints=LinearConstraint(A.tocsr(),np.array(los),np.array(his)),options={'time_limit':40,'mip_rel_gap':0,'presolve':True})
print('status',z.status,z.message,'success',z.success,'inc',z.x is not None,'sec',time.time()-st,flush=True)
if z.x is not None:
 sol=[]
 for i,(name,e,sh) in enumerate(classes):
  k=max(range(len(opts[i])),key=lambda q:z.x[starts[i]+q]);sol.append((name,e,opts[i][k]))
 open('/mnt/data/erdos2275/HEAVY_V3_002_DEEP_COMPAT_WITNESS.txt','w').write('\n'.join(map(str,sol)))
