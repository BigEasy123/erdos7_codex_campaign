#!/usr/bin/env python3
from fractions import Fraction as F
from itertools import product
import numpy as np,sys
from scipy.optimize import linprog
from scipy.sparse import lil_matrix
sys.path.insert(0,'/mnt/data/erdos2275')
import state2275_hn_milp as s
D=s.D; B=s.AT; N=len(B); PR=((1,3),(2,5),(4,7),(8,11)); FIX=set(s.FIX); FUT=set(s.FUT)
def bits(m):return tuple(i for i in range(4) if m>>i&1)
def G(m):
 z=F(1)
 for bit,p in PR:
  if m&bit:z*=F(p,p-1)
 return z
# fixed squarefree union already selected in state2275
bad=np.array([s.fixed_covered(a) for a in B],dtype=float)
# mu point variables + c_m cylinder maxima
nv=N+15
# deletion objective: exact fixed-base union + strict fixed tails + full future towers
obj=np.zeros(nv);obj[:N]=bad
for m in FIX: obj[N+m-1]+=float(G(m)-1)
for m in FUT: obj[N+m-1]+=float(G(m))
# all cylinder max constraints
rows=[]
for m in range(1,16):
 I=bits(m);gg={}
 for j,a in enumerate(B):gg.setdefault(tuple(a[i] for i in I),[]).append(j)
 for mem in gg.values():rows.append((m,mem))
# A_ub cylinder + BBMST functional cap
A=lil_matrix((len(rows)+1,nv));b=np.zeros(len(rows)+1)
for r,(m,mem) in enumerate(rows):
 for j in mem:A[r,j]=1
 A[r,N+m-1]=-1
# F = 1/4 + sum (3^|I|-3/4)c_I <= 861/128
r=len(rows)
for m in range(1,16):A[r,N+m-1]=3**m.bit_count()-.75
b[r]=float(F(861,128)-F(1,4))
E=np.zeros((1,nv));E[0,:N]=1
z=linprog(obj,A_ub=A.tocsr(),b_ub=b,A_eq=E,b_eq=[1],bounds=[(0,None)]*nv,method='highs')
print('success',z.success,z.message)
if z.success:
 eps=z.fun;Fval=.25+sum((3**m.bit_count()-.75)*z.x[N+m-1] for m in range(1,16))
 print('mixed deletion upper bound',eps)
 print('target',float(F(36679,140304)),'margin',float(F(36679,140304))-eps)
 print('Fstart',Fval,'cap',float(F(861,128)))
 print('fixed union mass',float(np.dot(bad,z.x[:N])))
 print('nonzero mu',sum(z.x[:N]>1e-10),'maxmu',z.x[:N].max())
 print('cylinders')
 for m in range(1,16):print(m,z.x[N+m-1])
