import sys,json,numpy as np
from scipy.optimize import linprog
from scipy.sparse import lil_matrix
from fractions import Fraction as F
sys.path.insert(0,'/mnt/data/erdos2275');import state2275_hn_milp as s
R=s.R;N=len(R);PR=((1,3),(2,5),(4,7),(8,11))
def bits(m):return tuple(i for i in range(4) if m>>i&1)
def G(m):
 z=F(1)
 for bit,p in PR:
  if m&bit:z*=F(p,p-1)
 return z
ex=set(json.load(open(sys.argv[1])));keep=[j for j in range(N) if j not in ex]
nv=N+15;c=np.zeros(nv)
for m in range(1,16):c[N+m-1]=float(G(m))
rows=[]
for m in range(1,16):
 I=bits(m);gg={}
 for j,a in enumerate(R):gg.setdefault(tuple(a[i] for i in I),[]).append(j)
 for mem in gg.values():rows.append((m,mem))
A=lil_matrix((len(rows),nv));b=np.zeros(len(rows))
for r,(m,mem) in enumerate(rows):
 for j in mem:A[r,j]=1
 A[r,N+m-1]=-1
E=np.zeros((1,nv));E[0,:N]=1
bounds=[(0,None) if j in keep else (0,0) for j in range(N)]+[(0,None)]*15
z=linprog(c,A_ub=A.tocsr(),b_ub=b,A_eq=E,b_eq=[1],bounds=bounds,method='highs')
print('success',z.success,'survive',len(keep),'B',1+z.fun if z.success else None,'nonzero',sum(z.x[:N]>1e-10) if z.success else None)
