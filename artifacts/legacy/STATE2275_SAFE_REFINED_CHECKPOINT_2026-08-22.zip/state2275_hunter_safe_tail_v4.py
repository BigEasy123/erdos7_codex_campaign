#!/usr/bin/env python3
import sys,time,json,pickle,os,argparse,numpy as np,networkx as nx
from scipy.optimize import milp,LinearConstraint
from scipy.sparse import vstack,lil_matrix
sys.path.insert(0,'/mnt/data/erdos2275')
import state2275_tower_heavy_bbmst_v4 as base
import state2275_hn_milp as s
R=s.R;N=len(R)
def deepmask(m,es):
 d=0
 for i,e in zip(s.bits(m),es):
  if e>1:d|=1<<i
 return d

def run(cut=.02,maxit=5,tlim=25,total=80,outcuts=None,out=None):
 c,ii,bd,con,meta=base.build(cut);A0=con.A;lo0=con.lb;hi0=con.ub;cuts=[];seen=set();records=[]
 xc={a:[] for a in range(N)}
 for (m,h,v),j in meta['xidx'].items():
  es,w=meta['hv'][m][h];dm=deepmask(m,es);I=s.bits(m)
  for ai,a in enumerate(R):
   if tuple(a[i] for i in I)==v:xc[ai].append((j,float(w),dm))
 tc={a:[] for a in range(N)}
 for (m,dm,v),j in meta['tidx'].items():
  I=s.bits(m);U=float(meta['tg'][m,dm])
  for ai,a in enumerate(R):
   if tuple(a[i] for i in I)==v:tc[ai].append((j,dm,U))
 st0=time.time();ans=None
 for it in range(maxit):
  if time.time()-st0>total:break
  if cuts:
   C=lil_matrix((len(cuts),len(c)));hi=[]
   for rr,(d,rhs) in enumerate(cuts):
    for j,v in d.items():C[rr,j]=v
    hi.append(rhs)
   A=vstack([A0,C.tocsr()],format='csr');lo=np.r_[lo0,np.full(len(cuts),-np.inf)];up=np.r_[hi0,np.array(hi)]
  else:A=A0;lo=lo0;up=hi0
  st=time.time();res=milp(c,integrality=ii,bounds=bd,constraints=LinearConstraint(A,lo,up),options={'time_limit':tlim,'mip_rel_gap':0,'presolve':True});sec=time.time()-st
  print('it',it,res.status,res.message,'inc',res.x is not None,'sec',round(sec,2),'cuts',len(cuts),flush=True)
  if res.x is None:ans={'status':'infeasible' if res.status==2 else 'unknown','cuts':len(cuts),'records':records};break
  ex=[a for a,j in meta['eidx'].items() if res.x[j]>.5];invalid=[];new=0
  for ai in ex:
   X=[x for x in xc[ai] if res.x[x[0]]>.5];T=[t for t in tc[ai] if res.x[t[0]]>1e-10]
   # exact maximum forest
   G=nx.Graph();G.add_nodes_from(range(len(X)))
   for u in range(len(X)):
    for v in range(u+1,len(X)):
     if X[u][2]&X[v][2]:continue
     G.add_edge(u,v,weight=X[u][1]*X[v][1])
   F=nx.maximum_spanning_tree(G,weight='weight');corrX=sum(G.edges[e]['weight'] for e in F.edges())
   # safe independent exact-neighbor CLUSTER for each tail: use all pairwise-disjoint/comparable? Conservative: best single exact.
   # plus tail-tail matching using residual dm (not radical m), much stronger than v3.
   attach=[]
   for jt,dm,U in T:
    tv=float(res.x[jt]);best=None
    for xi,x in enumerate(X):
     if x[2]&dm:continue
     val=x[1]*tv
     if best is None or val>best[0]:best=(val,xi)
    attach.append(best)
   GT=nx.Graph();GT.add_nodes_from(range(len(T)));ba=[0 if b is None else b[0] for b in attach]
   for i in range(len(T)):
    ji,mi,Ui=T[i];ti=float(res.x[ji])
    for j in range(i+1,len(T)):
     jj,mj,Uj=T[j];tj=float(res.x[jj])
     if mi&mj:continue
     L=Ui*tj+Uj*ti-Ui*Uj
     if L>0 and L-ba[i]-ba[j]>1e-12:GT.add_edge(i,j,weight=L-ba[i]-ba[j],L=L)
   mt=nx.max_weight_matching(GT,weight='weight') if GT.number_of_edges() else set();paired=set();pairs=[]
   for i,j in mt:paired|={i,j};pairs.append((i,j,GT.edges[i,j]['L']))
   leaf=[(i,b[1]) for i,b in enumerate(attach) if i not in paired and b is not None]
   sw=sum(x[1] for x in X)+sum(float(res.x[t[0]]) for t in T);corrL=sum(X[xi][1]*float(res.x[T[ti][0]]) for ti,xi in leaf);corrT=sum(L for _,_,L in pairs);cap=sw-corrX-corrL-corrT
   if cap>=1-1e-9:continue
   invalid.append((ai,cap));d={meta['eidx'][ai]:1.0};rhs=0.0
   for j,w,dm in X:d[j]=d.get(j,0)-w
   for j,dm,U in T:d[j]=d.get(j,0)-1
   for u,v in F.edges():
    ju,jv=X[u][0],X[v][0];ww=G.edges[u,v]['weight'];rhs+=ww;d[ju]=d.get(ju,0)+ww;d[jv]=d.get(jv,0)+ww
   for ti,xi in leaf:
    jt,dm,U=T[ti];jx,w,_=X[xi];rhs+=w*U;d[jx]=d.get(jx,0)+w*U;d[jt]=d.get(jt,0)+w
   for ti,tj,L in pairs:
    ji,mi,Ui=T[ti];jj,mj,Uj=T[tj];rhs+=Ui*Uj;d[ji]=d.get(ji,0)+Uj;d[jj]=d.get(jj,0)+Ui
   key=(ai,tuple(sorted((j,round(v,13)) for j,v in d.items() if abs(v)>1e-13)),round(rhs,13))
   if key not in seen:seen.add(key);cuts.append((d,rhs));new+=1
  rec={'it':it,'exhausted':len(ex),'invalid':len(invalid),'newcuts':new,'sec':sec,'mincap':min([x[1] for x in invalid],default=1)};records.append(rec);print(' ex',len(ex),'invalid',len(invalid),'new',new,'mincap',rec['mincap'],flush=True)
  if outcuts:pickle.dump({'cuts':cuts,'seen':seen,'records':records},open(outcuts,'wb'))
  if not invalid:ans={'status':'feasible_bad','cuts':len(cuts),'records':records};break
  if new==0:ans={'status':'stalled','cuts':len(cuts),'records':records};break
 if ans is None:ans={'status':'limit','cuts':len(cuts),'records':records}
 if out:json.dump(ans,open(out,'w'),indent=2)
 return ans
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--cut',type=float,default=.02);ap.add_argument('--maxit',type=int,default=5);ap.add_argument('--time',type=float,default=25);ap.add_argument('--total',type=float,default=80);ap.add_argument('--outcuts');ap.add_argument('--out');a=ap.parse_args();print(json.dumps(run(a.cut,a.maxit,a.time,a.total,a.outcuts,a.out),indent=2))
