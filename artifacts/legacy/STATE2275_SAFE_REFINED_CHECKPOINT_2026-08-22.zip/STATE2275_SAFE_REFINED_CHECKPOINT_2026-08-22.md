# Erdős #7 — State 2275 safe refined dispersion checkpoint

Date: 2026-08-22
Status: strong narrowing; **State 2275 not yet closed; no QED claimed**.

## 1. Rigor correction
The original 311 exact-heavy Hunter/CRT forest cuts remain valid. A later experimental exact-tail forest allowed one fractional tail node to have multiple exact neighbors; without a monotonicity condition this is not automatically a valid global upper bound. Those 59 experimental cuts are discarded for theorem-level use.

A corrected separator was implemented. It retains the exact-heavy Hunter forest, but each fractional tail group can only appear as a leaf against an exact event, or as one endpoint of a disjoint tail-tail matching edge. McCormick lower bounds make all resulting cuts globally valid.

## 2. Safe theta=0.02 branch-and-cut
Using the corrected safe separator at cutoff theta=0.02:

- initial bad master: 114 claimed exhausted parents, 89 invalid, 89 cuts;
- next: 41 claimed, 17 invalid, +17 cuts;
- next: 17 claimed, 8 invalid, +8 cuts;
- alternatives: 36/13 invalid, 34/20 invalid, 24/16 invalid, 17/8 invalid, 24/5 invalid, 42/12 invalid.

Current total: **188 rigorously valid safe cuts**.

The integer master continues to find alternate bad allocations, so pairwise/forest overlap alone has not closed 2275.

## 3. Exact local audit of a 17-parent witness
At the 163-cut stage, 9 of 17 claimed parents passed the safe local capacity test. Three were directly removed by a future squarefree base class. The remaining six shared shallow prefix `(a3,a5,a7)=(0,1,4)`.

For four of those six, the exact heavy residual moduli are essentially `3,9,5,5,3,15`. Exhaustive residue optimization modulo 45, with comparable-modulus incompatibility, gives exact-heavy union maximum

`41/45 = 0.911111111111...`.

The unresolved sub-0.02 tail is what pushes the safe upper bound back above 1. Therefore the obstruction has been localized into the small geometric tail, rather than the exposed heavy packet.

## 4. theta=0.01 check
The same safe separator at theta=0.01 gives:

- 88 claimed, 60 invalid, +60 cuts;
- 59 claimed, 26 invalid, +26 cuts.

The next integer master becomes materially harder. This confirms that exactifying the tail continues to remove many false exhaustions, but no closure is yet certified.

## 5. Residual-deep-support refinement
The aggregate tail on a radical support was split according to which prime coordinates remain genuinely deep after conditioning. For example, at theta=0.02 the unresolved radical `{3,5,7}` tail of total mass about 0.1376738473 splits across the seven nonempty residual supports as approximately

`0.0185185, 0.0100000, 0.0361111, 0.00340136, 0.0357143, 0.0130952, 0.0208333`.

This is a strictly tighter arbitrary-depth relaxation because each sub-tail has its own exact geometric budget and its own CRT independence relations.

All 188 safe theta=0.02 cuts lift exactly to this refined model by replacing each old aggregate tail variable with the sum of its residual-support sub-tail variables.

With the 188 translated cuts, HiGHS found no integer incumbent in an 18-second feasibility window; this is recorded only as computational hardness, not infeasibility.

The continuous relaxation is still loose: maximizing total fractional exhaustion gives

`sum e = 245.6756390230`, `max e = 1`, with 166 variables above 0.9.

Thus the remaining gap is genuinely combinatorial/integer, not a scalar-capacity inequality.

## 6. Neighbor-state audit
Among the 25 canonical states with the smallest exact arbitrary-depth low-four reserve, state 2275 is the only one whose Stage-24 adjusted squarefree BBMST value is above 9.019:

- 2275: 9.1088981837
- 2276: 8.9871964462
- 2277: 8.9872054528
- 2273: 8.9822050382
- 2274: 8.9825727210
- all other checked nearby states are lower still.

So 2275 is an isolated concentration spike. This does not automatically close the others under arbitrary-depth deletion, but it strongly supports attacking 2275 first and then lifting the final certificate.

## 7. Current decisive target
The tail/capacity hierarchy has reached its natural limit. The next theorem/computation should add the already-derived first-exhaustion structure to the refined master:

1. separate atoms deleted directly by future squarefree completion from genuinely deep exhaustions;
2. for each genuine first exhausted descendant, require either the exact-three chain/fork packet or the surplus-terminal packet;
3. add the corresponding comparable-residue blockers / triangle-gcd constraints;
4. run the joint BBMST/HN gate only on the surviving finite packet family.

If this closes state 2275 with a robust margin, use the same packet cuts on the nearby 90 Stage-24 states before considering a full 7637-state sweep.
