#!/usr/bin/env python3
from fractions import Fraction as F
from itertools import product
import math,sys,numpy as np
from scipy.optimize import LinearConstraint,Bounds
from scipy.sparse import lil_matrix
sys.path.insert(0,'/mnt/data/erdos2275')
import state2275_hn_milp as s
R=s.R;N=len(R);FIX=set(s.FIX);MIXED={m for m in range(1,16) if m.bit_count()>=2};FUT=MIXED-FIX
PR=((1,3),(2,5),(4,7),(8,11));ZF=9.019-.25

def bits(m):return tuple(i for i in range(4) if m>>i&1)
def deepmask(m,es):
 d=0
 for i,e in zip(bits(m),es):
  if e>1:d|=1<<i
 return d
def Gall(m):
 z=F(1)
 for bit,p in PR:
  if m&bit:z*=F(p,p-1)
 return z
f={m:(Gall(m) if m in FUT else Gall(m)-1) for m in range(1,16)}
cyl={};atom_cyl={j:[] for j in range(N)}
for m in range(1,16):
 I=bits(m);g={}
 for j,a in enumerate(R):g.setdefault(tuple(a[i] for i in I),[]).append(j)
 for v,mem in g.items():
  cyl[m,v]=mem
  for j in mem:atom_cyl[j].append((m,v))
keys=list(cyl)

def heavy_vectors(m,cut):
 ps=[p for bit,p in PR if m&bit];maxes=[1+int(math.floor(math.log(1/cut,p)))+1 for p in ps];arr=[]
 for es in product(*[range(1,M+1) for M in maxes]):
  w=F(1)
  for p,e in zip(ps,es):w*=F(1,p**(e-1))
  if float(w)+1e-15<cut:continue
  if m not in FUT and all(e==1 for e in es):continue
  arr.append((es,w))
 return arr

def tail_groups(m,hv):
 # exact infinite conditional reciprocal mass by residual-deep support dm, minus enumerated heavy vectors.
 out={}
 for dm in range(1,16):
  if dm&~m:continue
  z=F(1)
  for bit,p in PR:
   if dm&bit:z*=F(1,p-1)
  out[dm]=z
 # subtract heavy vectors, ignoring dm=0 squarefree base
 for es,w in hv:
  dm=deepmask(m,es)
  if dm:out[dm]-=w
 return {dm:z for dm,z in out.items() if z>0}

def build(cut=.02):
 hv={m:heavy_vectors(m,cut) for m in range(1,16)}
 tg={}
 for m in range(1,16):
  for dm,z in tail_groups(m,hv[m]).items():tg[m,dm]=z
 names=[];lb=[];ub=[];integ=[]
 def add(n,lo=0,hi=np.inf,integer=False):
  j=len(names);names.append(n);lb.append(lo);ub.append(hi);integ.append(1 if integer else 0);return j
 xidx={}
 for m in range(1,16):
  mkeys=[k for k in keys if k[0]==m]
  for h,(es,w) in enumerate(hv[m]):
   allowed={tuple(v) for v in s.Q[m]} if (m in FUT and all(e==1 for e in es)) else None
   for k in mkeys:
    if allowed is not None and tuple(k[1]) not in allowed:continue
    xidx[m,h,k[1]]=add(('x',m,h,es,k[1]),0,1,True)
 tidx={}
 for (m,dm),U in tg.items():
  for k in keys:
   if k[0]==m:tidx[m,dm,k[1]]=add(('tail',m,dm,k[1]),0,float(U))
 eidx={j:add(('e',j),0,1,True) for j in range(N)}
 yidx={k:add(('y',)+k,0,np.inf) for k in keys}
 rows=[];los=[];his=[]
 def row(d,lo=-np.inf,hi=np.inf):rows.append(d);los.append(lo);his.append(hi)
 # heavy modulus residue choices
 for m in range(1,16):
  for h,(es,w) in enumerate(hv[m]):
   ids=[j for (mm,hh,v),j in xidx.items() if mm==m and hh==h]
   if m in FUT and all(e==1 for e in es):
    if not ids:return None
    row({j:1 for j in ids},1,1)
   else:row({j:1 for j in ids},hi=1)
 # future squarefree comparable
 baseh={}
 for m in FUT:
  for h,(es,w) in enumerate(hv[m]):
   if all(e==1 for e in es):baseh[m]=h;break
 for m in FUT:
  Im=bits(m);hm=baseh[m]
  for n in FUT:
   if m>=n or (m&~n):continue
   In=bits(n);hn=baseh[n]
   for (mm,hh,mv),jm in list(xidx.items()):
    if mm!=m or hh!=hm:continue
    js=[jn for (nn,h2,nv),jn in xidx.items() if nn==n and h2==hn and s.restrict(nv,In,Im)==mv]
    if js:row({jm:1,**{j:1 for j in js}},hi=1)
 # future base vs higher heavy
 for m in FUT:
  Im=bits(m);hm=baseh[m]
  for U in range(1,16):
   if m&~U:continue
   IU=bits(U)
   for hu,(es,w) in enumerate(hv[U]):
    if U==m and all(e==1 for e in es):continue
    for (mm,hh,mv),jm in list(xidx.items()):
     if mm!=m or hh!=hm:continue
     js=[ju for (uu,h2,uv),ju in xidx.items() if uu==U and h2==hu and s.restrict(uv,IU,Im)==mv]
     if js:row({jm:1,**{j:1 for j in js}},hi=1)
 # divisor completion among represented heavy vectors
 for m in range(1,16):
  es_to_h={tuple(es):h for h,(es,w) in enumerate(hv[m])}
  for h,(es,w) in enumerate(hv[m]):
   for i,e in enumerate(es):
    if e<=1:continue
    par=list(es);par[i]-=1;hp=es_to_h.get(tuple(par))
    if hp is None:continue
    child=[j for (mm,hh,v),j in xidx.items() if mm==m and hh==h];parent=[j for (mm,hh,v),j in xidx.items() if mm==m and hh==hp]
    if child:
     d={j:1 for j in child}
     for j in parent:d[j]=d.get(j,0)-1
     row(d,hi=0)
 # each residual-deep-support tail group has its own total geometric budget
 for (m,dm),U in tg.items():
  ids=[j for (mm,dd,v),j in tidx.items() if mm==m and dd==dm]
  row({j:1 for j in ids},hi=float(U))
 # exhaustion load
 for ai,a in enumerate(R):
  d={eidx[ai]:-1}
  for m in range(1,16):
   I=bits(m);v=tuple(a[i] for i in I)
   for h,(_,w) in enumerate(hv[m]):
    j=xidx.get((m,h,v))
    if j is not None:d[j]=d.get(j,0)+float(w)
   for dm in [dd for (mm,dd) in tg if mm==m]:
    j=tidx.get((m,dm,v))
    if j is not None:d[j]=d.get(j,0)+1
  row(d,lo=0)
 # BBMST bad dual
 for m in range(1,16):row({yidx[k]:1 for k in keys if k[0]==m},hi=3**m.bit_count()-.75)
 for ai in range(N):
  d={eidx[ai]:ZF}
  for k in atom_cyl[ai]:d[yidx[k]]=1
  row(d,lo=ZF)
 row({eidx[j]:1 for j in range(N)},hi=N-1)
 n=len(names);A=lil_matrix((len(rows),n))
 for r,d in enumerate(rows):
  for j,v in d.items():A[r,j]=v
 meta=dict(names=names,eidx=eidx,xidx=xidx,tidx=tidx,hv=hv,tg=tg,nvars=n,nbin=sum(integ),nrows=len(rows))
 return np.zeros(n),np.array(integ),Bounds(np.array(lb),np.array(ub)),LinearConstraint(A.tocsr(),np.array(los),np.array(his)),meta
