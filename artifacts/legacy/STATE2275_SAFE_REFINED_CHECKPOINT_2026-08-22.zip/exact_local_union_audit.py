#!/usr/bin/env python3
import sys,json,ast,math,itertools
from functools import reduce
sys.path.insert(0,'/mnt/data/erdos2275')
import state2275_hn_milp as s
import state2275_tower_heavy_bbmst_v3 as base
P=(3,5,7,11)
D=json.load(open('/mnt/data/erdos2275/HUNTER002_AFTER163_WITNESS.json'));meta=base.build(.02)[-1]

def bits(m):return s.bits(m)
def full_exp(m,es):
 out=[0]*4
 for i,e in zip(bits(m),es):out[i]=e
 return tuple(out)
def orig_mod(E):
 z=1
 for p,e in zip(P,E):z*=p**e
 return z
def residual_mod(E):
 z=1
 for p,e in zip(P,E):
  if e>=2:z*=p**(e-1)
 return z
def divides(E,F):return all(a<=b for a,b in zip(E,F))
sel=[]
for rec in D['selected']:
 nm=ast.literal_eval(rec['name']);_,m,h,es,v=nm;E=full_exp(m,es);q=residual_mod(E);sel.append((m,h,tuple(es),tuple(v),E,q))
tails=[(r['m'],tuple(r['v']),float(r['value'])) for r in D['tails']]

def incident(a):
 X=[];T=[]
 for rec in sel:
  m,h,es,v,E,q=rec;I=bits(m)
  if tuple(a[i] for i in I)==v:X.append(rec)
 for m,v,val in tails:
  I=bits(m)
  if tuple(a[i] for i in I)==v:T.append((m,v,val))
 return X,T

def exact_max(X):
 if any(q==1 for *_,q in X):return 1.0,None,1
 qs=[q for *_,q in X];L=math.lcm(*qs) if qs else 1
 # pair comparability constraints: if Ei|Ej, residues must differ modulo qi (unless qi=1 already handled)
 comp=[]
 for i in range(len(X)):
  Ei=X[i][4];qi=X[i][5]
  for j in range(i+1,len(X)):
   Ej=X[j][4];qj=X[j][5]
   if divides(Ei,Ej):comp.append((i,j,qi))
   elif divides(Ej,Ei):comp.append((j,i,qj))
 best=-1;bestres=None;nodes=0
 # order vars by q descending / constraints
 order=sorted(range(len(X)),key=lambda i:(-qs[i],i)); pos={v:k for k,v in enumerate(order)}
 assigned=[None]*len(X)
 masks=[[x for x in range(L) if x%q==r] for q in qs for r in []] # unused
 def ok_set(i,r):
  for small,big,qsmall in comp:
   if i==small and assigned[big] is not None:
    if assigned[big]%qsmall==r%qsmall:return False
   if i==big and assigned[small] is not None:
    if r%qsmall==assigned[small]%qsmall:return False
  return True
 def dfs(k,cov):
  nonlocal best,bestres,nodes
  nodes+=1
  if k==len(order):
   n=cov.bit_count()
   if n>best:best=n;bestres=assigned.copy()
   return
  i=order[k];q=qs[i]
  # dedupe residues with same incremental mask not needed
  for r in range(q):
   if not ok_set(i,r):continue
   assigned[i]=r
   bm=0
   for x in range(r,L,q):bm|=1<<x
   dfs(k+1,cov|bm)
   assigned[i]=None
 dfs(0,0)
 return best/L,bestres,nodes

for atom in D['exhausted_atoms']:
 a=tuple(atom);X,T=incident(a)
 if any(x[-1]==1 for x in X):continue
 # focus plausible-looking prefix
 if a[:3]!=(0,1,4):continue
 mx,res,nodes=exact_max(X);ts=sum(v for _,_,v in T)
 print('\nATOM',a,'L exactmax',mx,'tailsum',ts,'upper',mx+ts,'nodes',nodes)
 print(' X',[(x[0],x[2],x[5]) for x in X])
 print(' residues',res)
 print(' T',[(m,round(v,9)) for m,_,v in T])
