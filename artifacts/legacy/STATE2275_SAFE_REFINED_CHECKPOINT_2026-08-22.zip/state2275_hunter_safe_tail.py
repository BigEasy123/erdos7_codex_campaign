#!/usr/bin/env python3
from fractions import Fraction as F
import sys,time,math,json,pickle,os,argparse,ast
import numpy as np, networkx as nx
from scipy.optimize import milp,LinearConstraint
from scipy.sparse import vstack,lil_matrix
sys.path.insert(0,'/mnt/data/erdos2275')
import state2275_tower_heavy_bbmst_v3 as base
import state2275_hn_milp as s
P=(3,5,7,11);R=s.R;N=len(R)

def deepmask(m,es):
 d=0
 for i,e in zip(s.bits(m),es):
  if e>1:d|=1<<i
 return d

def run(cut=.05,maxit=10,tlim=25,total=100,incuts=None,outcuts=None,out=None,witness=None):
 z=base.build(cut)
 if z is None:return {'status':'preinf'}
 c,ii,bd,con,meta=z;A0=con.A;lo0=con.lb;hi0=con.ub
 cuts=[];seen=set();records=[]
 if incuts and os.path.exists(incuts):
  p=pickle.load(open(incuts,'rb'));cuts=p.get('cuts',[]);seen=p.get('seen',set());records=p.get('records',[])
  print('loaded',len(cuts),'cuts',len(records),'records',flush=True)
 # exact candidates per atom: var, mass, deepmask
 xcand={a:[] for a in range(N)}
 for (m,h,v),j in meta['xidx'].items():
  es,w=meta['hv'][m][h];dm=deepmask(m,es);I=s.bits(m)
  for ai,a in enumerate(R):
   if tuple(a[i] for i in I)==v:xcand[ai].append((j,float(w),dm,m,h,tuple(es)))
 # tail candidates per atom: var, full radical mask, cap U
 tcand={a:[] for a in range(N)}
 for (m,v),j in meta['tidx'].items():
  I=s.bits(m);U=float(meta['tail'][m])
  for ai,a in enumerate(R):
   if tuple(a[i] for i in I)==v:tcand[ai].append((j,m,U))
 st0=time.time();ans=None
 for it in range(maxit):
  if time.time()-st0>total:break
  if cuts:
   C=lil_matrix((len(cuts),len(c)));chi=[]
   for rr,(d,rhs) in enumerate(cuts):
    for j,v in d.items():C[rr,j]=v
    chi.append(rhs)
   A=vstack([A0,C.tocsr()],format='csr');lo=np.r_[lo0,np.full(len(cuts),-np.inf)];hi=np.r_[hi0,np.array(chi)]
  else:A=A0;lo=lo0;hi=hi0
  st=time.time();res=milp(c,integrality=ii,bounds=bd,constraints=LinearConstraint(A,lo,hi),options={'time_limit':tlim,'mip_rel_gap':0,'presolve':True});sec=time.time()-st
  print('it',it,'status',res.status,res.message,'inc',res.x is not None,'sec',round(sec,3),'cuts',len(cuts),flush=True)
  if res.x is None:
   ans={'status':'infeasible' if res.status==2 else 'unknown','cuts':len(cuts),'records':records,'elapsed':time.time()-st0};break
  ex=[a for a,j in meta['eidx'].items() if res.x[j]>.5]
  invalid=[];new=0
  for ai in ex:
   X=[q for q in xcand[ai] if res.x[q[0]]>.5]
   T=[q for q in tcand[ai] if res.x[q[0]]>1e-10]
   # exact-heavy Hunter maximum spanning forest
   GX=nx.Graph();GX.add_nodes_from(range(len(X)))
   for u in range(len(X)):
    for v in range(u+1,len(X)):
     if X[u][2]&X[v][2]:continue
     GX.add_edge(u,v,weight=X[u][1]*X[v][1])
   FX=nx.maximum_spanning_tree(GX,weight='weight')
   corrX=sum(GX.edges[e]['weight'] for e in FX.edges())
   # Each tail may be a LEAF on at most one exact node; this guarantees monotonicity in tail mass.
   attach=[]
   for ti,(jt,mt,U) in enumerate(T):
    tv=float(res.x[jt]);best=None
    for xi,x in enumerate(X):
     if x[2]&mt:continue
     val=x[1]*tv
     if best is None or val>best[0]:best=(val,xi)
    attach.append(best)
   # Optional disjoint tail-tail matching.  Use McCormick lower intersection at current point.
   # Compare a paired correction to sacrificing the two individual exact-leaf attachments.
   GT=nx.Graph();GT.add_nodes_from(range(len(T)))
   baseatt=[0.0 if b is None else b[0] for b in attach]
   for i in range(len(T)):
    ji,mi,Ui=T[i];ti=float(res.x[ji])
    for j in range(i+1,len(T)):
     jj,mj,Uj=T[j];tj=float(res.x[jj])
     if mi&mj:continue
     L=Ui*tj+Uj*ti-Ui*Uj
     if L<=0:continue
     gain=L-baseatt[i]-baseatt[j]
     if gain>1e-12:GT.add_edge(i,j,weight=gain,L=L)
   matching=nx.max_weight_matching(GT,maxcardinality=False,weight='weight') if GT.number_of_edges() else set()
   paired=set();pairs=[]
   for i,j in matching:
    if i>j:i,j=j,i
    paired|={i,j};pairs.append((i,j,GT.edges[i,j]['L']))
   leafedges=[]
   for ti,b in enumerate(attach):
    if ti in paired or b is None:continue
    leafedges.append((ti,b[1]))
   sw=sum(x[1] for x in X)+sum(float(res.x[t[0]]) for t in T)
   corrLeaf=sum(X[xi][1]*float(res.x[T[ti][0]]) for ti,xi in leafedges)
   corrTT=sum(L for _,_,L in pairs)
   cap=sw-corrX-corrLeaf-corrTT
   if cap>=1-1e-9:continue
   invalid.append((ai,cap,len(X),len(T),len(FX.edges()),len(leafedges),len(pairs)))
   # globally valid linear upper-bound cut
   d={meta['eidx'][ai]:1.0};rhs=0.0
   for j,w,*_ in X:d[j]=d.get(j,0)-w
   for j,m,U in T:d[j]=d.get(j,0)-1.0
   for u,v in FX.edges():
    ju=X[u][0];jv=X[v][0];ww=GX.edges[u,v]['weight'];rhs+=ww;d[ju]=d.get(ju,0)+ww;d[jv]=d.get(jv,0)+ww
   for ti,xi in leafedges:
    jt,mt,U=T[ti];jx,w,*_=X[xi]
    # overlap >= w*(t-U(1-x))
    rhs+=w*U;d[jx]=d.get(jx,0)+w*U;d[jt]=d.get(jt,0)+w
   for ti,tj,Lcur in pairs:
    ji,mi,Ui=T[ti];jj,mj,Uj=T[tj]
    # t_i t_j >= U_i t_j + U_j t_i - U_i U_j
    rhs+=Ui*Uj;d[ji]=d.get(ji,0)+Uj;d[jj]=d.get(jj,0)+Ui
   key=(ai,tuple(sorted((j,round(v,13)) for j,v in d.items() if abs(v)>1e-13)),round(rhs,13),'safe')
   if key not in seen:seen.add(key);cuts.append((d,rhs));new+=1
  rec={'phase':'safe-tail','iter':it,'exhausted':len(ex),'invalid':len(invalid),'newcuts':new,'sec':sec,'mincap':min([q[1] for q in invalid],default=1.0),'maxcap':max([q[1] for q in invalid],default=1.0)};records.append(rec)
  print(' ex',len(ex),'invalid',len(invalid),'new',new,'cap',rec['mincap'],rec['maxcap'],flush=True)
  if outcuts:pickle.dump({'cuts':cuts,'seen':seen,'records':records},open(outcuts,'wb'))
  if not invalid:
   ans={'status':'safe_tail_feasible_bad','cuts':len(cuts),'records':records,'elapsed':time.time()-st0}
   if witness:
    selected=[{'j':j,'name':repr(nm),'value':float(res.x[j])} for j,nm in enumerate(meta['names']) if res.x[j]>.5 and nm[0]=='x']
    tails=[{'m':m,'v':list(v),'value':float(res.x[j])} for (m,v),j in meta['tidx'].items() if res.x[j]>1e-8]
    json.dump({'selected':selected,'tails':tails,'exhausted_atoms':[list(R[a]) for a in ex],'nselected':len(selected),'ntails':len(tails)},open(witness,'w'),indent=2)
   break
  if new==0:
   ans={'status':'stalled','cuts':len(cuts),'records':records,'elapsed':time.time()-st0};break
 if ans is None:ans={'status':'limit','cuts':len(cuts),'records':records,'elapsed':time.time()-st0}
 if out:json.dump(ans,open(out,'w'),indent=2)
 return ans

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--cut',type=float,default=.05);ap.add_argument('--maxit',type=int,default=10);ap.add_argument('--time',type=float,default=25);ap.add_argument('--total',type=float,default=100);ap.add_argument('--incuts');ap.add_argument('--outcuts');ap.add_argument('--out');ap.add_argument('--witness');a=ap.parse_args();print(json.dumps(run(a.cut,a.maxit,a.time,a.total,a.incuts,a.outcuts,a.out,a.witness),indent=2))
