#!/usr/bin/env python3
import sys,pickle
sys.path.insert(0,'/mnt/data/erdos2275')
import state2275_tower_heavy_bbmst_v3 as v3
import state2275_tower_heavy_bbmst_v4 as v4
cut=.02
old=v3.build(cut)[-1];new=v4.build(cut)[-1]
oldcuts=pickle.load(open('/mnt/data/erdos2275/HUNTER002_SAFE_CUTS.pkl','rb'))
newname_to_idx={repr(n):i for i,n in enumerate(new['names'])}
# explicit structural lookup for new tails
newtail={}
for (m,dm,v),j in new['tidx'].items():newtail.setdefault((m,v),[]).append(j)
out=[]
for d,rhs in oldcuts['cuts']:
 nd={}
 for j,coef in d.items():
  nm=old['names'][j]
  if nm[0]=='tail':
   _,m,v=nm
   ids=newtail.get((m,v),[])
   if not ids:
    # aggregate tail vanished under decomposition: coefficient contributes nothing
    continue
   for jj in ids:nd[jj]=nd.get(jj,0)+coef
  else:
   jj=newname_to_idx.get(repr(nm))
   if jj is None:
    raise RuntimeError(('missing',nm))
   nd[jj]=nd.get(jj,0)+coef
 out.append((nd,rhs))
pickle.dump({'cuts':out,'seen':set(),'records':[{'translated_from_v3_safe':len(out)}]},open('/mnt/data/erdos2275/HUNTER002_V4_TRANSLATED_CUTS.pkl','wb'))
print('translated',len(out),'oldvars',len(old['names']),'newvars',len(new['names']))
